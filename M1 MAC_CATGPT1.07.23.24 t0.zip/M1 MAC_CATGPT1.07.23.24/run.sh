#!/usr/bin/env bash

function find_python_command() {
    for cmd in python3.11 python3.10 python3 python; do
        if command -v $cmd &> /dev/null; then
            if $cmd -c "import sys; sys.exit(sys.version_info < (3, 10))"; then
                echo $cmd
                return
            fi
        fi
    done
    echo "Python 3.10 or higher not found. Please install Python 3.10+."
    exit 1
}

PYTHON_CMD=$(find_python_command)

echo "Using Python command: $PYTHON_CMD"
$PYTHON_CMD --version

if $PYTHON_CMD scripts/check_requirements.py requirements.txt; then
    echo "All requirements satisfied."
else
    echo "Installing missing packages..."
    $PYTHON_CMD -m pip install -r requirements.txt
fi

$PYTHON_CMD -m autogpt "$@"

read -p "Press Enter to continue..."